Attribute VB_Name = "VerseVocalizer"
Option Explicit
' GROUP: פסוקים
' ORDER: 5
' Select any passage of Tanakh (one or more verses, spelled with or without nikud) and run
' ReplaceWithVocalizedVerse. The selection is replaced by ALL the verses it touches,
' with nikud and taamim. Works offline, using the data file tanakh.txt.
'
' Data file lines:  reference <TAB> letters only <TAB> full verse with nikud and taamim
Private Const DATA_NAME As String = "tanakh.txt"
' Optional: font for the inserted text, e.g. "SBL Hebrew" or "Ezra SIL". Leave empty to keep the current font.
Private Const VERSE_FONT As String = ""
Private Const MAX_SHOW As Long = 10
Private mLoaded As Boolean
Private mCount As Long
Private mRefs() As String
Private mFull() As String
Private mStart() As Long
Private mCorpus As String
' True when the last call continued WITHOUT a verse (text not found and the user chose to continue)
Public VerseSkipped As Boolean
' In the full Nikud package this flag lives in AllActions; here there is no pipeline, so it is always False.
Public PipelineQuiet As Boolean
' BUTTON: החלף בפסוק מנוקד
' ICON: verse_nikud
Public Sub ReplaceWithVocalizedVerse()
    Dim r As Range
    ReplaceSelectionWithVerses r
End Sub
' Type the beginning of a verse (with or without nikud) and the verse is shown. When several verses start the
' same way a numbered list is shown to choose from. If nothing starts that way, the text is searched anywhere
' inside the verses. After the verse is shown you can insert it into the document.
' BUTTON: חפש פסוק לפי התחלה
' ICON: search
Public Sub SearchVerseByStart()
    Const MAX_LIST As Long = 12
    Dim ans As String, S As String, msg As String
    Dim hits(1 To MAX_LIST) As Long
    Dim nTotal As Long, nList As Long, i As Long, v As Long, last As Long, p As Long
    Dim picked As Long, num As Long

    On Error GoTo Fail
    ans = InputBox("כתבו תחילת פסוק (עם ניקוד או בלי)," & vbCrLf & "או שם פרשה / ספר + פרק + פסוק, למשל:  וישלח לב ד", "חיפוש פסוק")
    If Len(Trim$(ans)) = 0 Then Exit Sub
    If Not EnsureData() Then Exit Sub

    ' a reference (parasha / book + chapter + verse) is shown directly
    If ReferenceLookup(ans, picked) Then
        If picked > 0 Then
            ShowVerse picked
        Else
            MsgBox "הפסוק לא קיים. בדקו את מספר הפרק והפסוק.", vbInformation + vbMsgBoxRtlReading + vbMsgBoxRight, "חיפוש פסוק"
        End If
        GoTo Done
    End If

    S = StripToLetters(ans)
    If Len(S) < 2 Then
        MsgBox "הטקסט קצר מדי לחיפוש.", vbInformation + vbMsgBoxRtlReading + vbMsgBoxRight, "חיפוש פסוק"
        Exit Sub
    End If

    ' 1. verses that START with the typed text
    For i = 1 To mCount
        If VerseLength(i) >= Len(S) Then
            If Mid$(mCorpus, mStart(i), Len(S)) = S Then
                nTotal = nTotal + 1
                If nList < MAX_LIST Then nList = nList + 1: hits(nList) = i
            End If
        End If
    Next i

    ' 2. nothing starts that way: look for the text anywhere inside a verse
    If nTotal = 0 Then
        last = 0
        p = InStr(1, mCorpus, S, vbBinaryCompare)
        Do While p > 0
            v = VerseAt(p)
            If v <> last And p + Len(S) - 1 < mStart(v) + VerseLength(v) Then
                nTotal = nTotal + 1
                last = v
                If nList < MAX_LIST Then nList = nList + 1: hits(nList) = v
            End If
            p = InStr(p + 1, mCorpus, S, vbBinaryCompare)
        Loop
    End If

    If nTotal = 0 Then
        MsgBox "לא נמצא פסוק." & vbCrLf & "בדקו את הכתיב (מלא / חסר חייב להתאים לנוסח המסורה).", _
               vbInformation + vbMsgBoxRtlReading + vbMsgBoxRight, "חיפוש פסוק"
        GoTo Done
    ElseIf nTotal = 1 Then
        picked = hits(1)
    Else
        msg = "נמצאו " & nTotal & " פסוקים. הקלידו את המספר:" & vbCrLf & vbCrLf
        For i = 1 To nList
            msg = msg & i & ") " & mRefs(hits(i)) & "   " & Left$(StripToLetters(mFull(hits(i))), 35) & vbCrLf
        Next i
        If nTotal > nList Then msg = msg & vbCrLf & "(מוצגים הראשונים בלבד - הוסיפו עוד מילים כדי לצמצם)"
        ans = InputBox(msg, "חיפוש פסוק", "1")
        If Not IsNumeric(ans) Then GoTo Done
        num = CLng(ans)
        If num < 1 Or num > nList Then GoTo Done
        picked = hits(num)
    End If

    ShowVerse picked

Done:
    Application.StatusBar = False
    Exit Sub
Fail:
    MsgBox "Error: " & Err.Description, vbCritical
    Resume Done
End Sub

' Length (in letters + spaces) of verse i inside mCorpus.
Private Function VerseLength(ByVal i As Long) As Long
    If i < mCount Then
        VerseLength = mStart(i + 1) - mStart(i) - 1
    Else
        VerseLength = Len(mCorpus) - mStart(i) + 1
    End If
End Function

' Replaces the selection by the verses it touches. On success returns True and result = the new text.
Public Function ReplaceSelectionWithVerses(ByRef result As Range) As Boolean
    Dim rng As Range
    Dim S As String
    Dim hitA(1 To MAX_SHOW + 1) As Long
    Dim hitB(1 To MAX_SHOW + 1) As Long
    Dim nHits As Long, k As Long, p As Long, a As Long, b As Long
    Dim dup As Boolean
    Dim chosenA As Long, chosenB As Long
    VerseSkipped = False
    If Selection.Type = wdSelectionIP Then
        MsgBox "Select a passage first.", vbExclamation
        Exit Function
    End If
    Set rng = Selection.Range
    ' do not swallow the paragraph mark / cell marker at the end of the selection
    Do While rng.End > rng.Start
        Select Case AscW(Right$(rng.Text, 1))
            Case 13, 7, 10, 11, 12
                rng.MoveEnd wdCharacter, -1
            Case Else
                Exit Do
        End Select
    Loop
    S = StripToLetters(rng.Text)
    If Len(S) < 3 Then
        If ContinueWithoutVerse(rng, result, _
                "The selection is too short to identify a verse.", _
                "הטקסט המסומן קצר מדי כדי לזהות פסוק.") Then ReplaceSelectionWithVerses = True
        Exit Function
    End If
    On Error GoTo Fail
    If Not EnsureData() Then Exit Function
    ' exact search of the selection (letters only) inside the whole Tanakh
    p = InStr(1, mCorpus, S, vbBinaryCompare)
    Do While p > 0 And nHits <= MAX_SHOW
        a = VerseAt(p)
        b = VerseAt(p + Len(S) - 1)
        dup = False
        For k = 1 To nHits
            If hitA(k) = a And hitB(k) = b Then
                dup = True
                Exit For
            End If
        Next k
        If Not dup Then
            nHits = nHits + 1
            hitA(nHits) = a
            hitB(nHits) = b
        End If
        p = InStr(p + 1, mCorpus, S, vbBinaryCompare)
    Loop
    If nHits = 0 Then
        If Not FindByEnds(S, a, b) Then
            If ContinueWithoutVerse(rng, result, _
                    "The selection was not found in the Tanakh." & vbCrLf & _
                    "Check the spelling (full / defective spelling must match the Masoretic text).", _
                    "הטקסט המסומן לא נמצא בתנ""ך." & vbCrLf & _
                    "בדקו את הכתיב (מלא / חסר חייב להתאים לנוסח המסורה).") Then ReplaceSelectionWithVerses = True
            GoTo Done
        End If
        If MsgBox("The selection does not match the text exactly (spelling differences?)." & vbCrLf & _
                  "Replace it with: " & RangeLabel(a, b) & " ?", vbYesNo + vbQuestion) <> vbYes Then GoTo Done
        chosenA = a
        chosenB = b
    ElseIf nHits > MAX_SHOW Then
        MsgBox "Too many matches. Select a longer passage.", vbInformation
        GoTo Done
    ElseIf nHits = 1 Then
        chosenA = hitA(1)
        chosenB = hitB(1)
    Else
        If Not PickHit(hitA, hitB, nHits, chosenA, chosenB) Then GoTo Done
    End If
    rng.Text = JoinVerses(chosenA, chosenB)
    If Len(VERSE_FONT) > 0 Then
        rng.Font.Name = VERSE_FONT
        rng.Font.NameBi = VERSE_FONT
    End If
    Set result = rng
    ReplaceSelectionWithVerses = True
Done:
    Application.StatusBar = False
    Exit Function
Fail:
    MsgBox "Error: " & Err.Description, vbCritical
    Resume Done
End Function
' Used when no verse can be matched. Outside the "All actions" pipeline: shows the message and returns False (stop).
' Inside the pipeline: shows the message with a Yes / No choice. Yes = continue the remaining actions on the
' selected text as it is (result = the selection, VerseSkipped = True). No = stop.
Private Function ContinueWithoutVerse(ByVal rng As Range, ByRef result As Range, _
                                      ByVal msgEn As String, ByVal msgHe As String) As Boolean
    If Not PipelineQuiet Then
        MsgBox msgEn, vbExclamation
        Exit Function
    End If
    If MsgBox(msgHe & vbCrLf & vbCrLf & _
              "להמשיך בשאר הפעולות על הטקסט המסומן כפי שהוא (בלי החלפה בפסוק)?", _
              vbYesNo + vbExclamation + vbMsgBoxRtlReading + vbMsgBoxRight, "כל הפעולות") = vbYes Then
        VerseSkipped = True
        Set result = rng
        ContinueWithoutVerse = True
    End If
End Function

' Lets you point the macro to tanakh.txt again (for example after moving the file).
Public Sub ChooseDataFile()
    Dim p As String
    p = PickDataFile()
    If Len(p) > 0 Then
        SaveSetting "VerseVocalizer", "Settings", "DataFile", p
        mLoaded = False
    End If
End Sub
' ---------------------------------------------------------------- reference lookup
' Typed reference: [parasha or book name] [chapter] [verse], e.g.  וישלח לב ד   /   פרשת וישלח פרק לב פסוק ד   /   בראשית 32:4
' Returns True when the text is a reference (idx = the verse, or 0 when that verse does not exist).
Private Function ReferenceLookup(ByVal txt As String, ByRef idx As Long) As Boolean
    Dim w() As String, t() As String
    Dim s As String, cand As String, book As String, target As String
    Dim n As Long, i As Long, k As Long, m As Long, used As Long, ch As Long, vs As Long
    idx = 0
    s = NormalizeRef(txt)
    If Len(s) = 0 Then Exit Function
    w = Split(s, " ")
    ReDim t(0 To UBound(w))
    For i = 0 To UBound(w)
        Select Case w(i)
            Case "", ChrW(&H5E4) & ChrW(&H5E8) & ChrW(&H5E9) & ChrW(&H5EA), _
                 ChrW(&H5E4) & ChrW(&H5E8) & ChrW(&H5E9) & ChrW(&H5D4), _
                 ChrW(&H5E4) & ChrW(&H5E8) & ChrW(&H5E7), _
                 ChrW(&H5E4) & ChrW(&H5E1) & ChrW(&H5D5) & ChrW(&H5E7), _
                 ChrW(&H5E1) & ChrW(&H5E4) & ChrW(&H5E8)
                ' filler words: parashat, parasha, perek, pasuk, sefer
            Case Else
                t(n) = w(i): n = n + 1
        End Select
    Next i
    If n < 3 Then Exit Function
    For k = 3 To 1 Step -1                       ' longest name first
        If n - k = 2 Then
            cand = t(0)
            For m = 1 To k - 1
                cand = cand & " " & t(m)
            Next m
            book = BookOfAlias(cand)
            If Len(book) > 0 Then used = k: Exit For
        End If
    Next k
    If Len(book) = 0 Then Exit Function
    ch = RefNumber(t(used))
    vs = RefNumber(t(used + 1))
    If ch = 0 Or vs = 0 Then Exit Function
    ReferenceLookup = True
    target = book & " " & ch & ":" & vs
    For i = 1 To mCount
        If mRefs(i) = target Then idx = i: Exit For
    Next i
End Function

' Hebrew letters and digits stay, nikud / taamim / quote marks are dropped, everything else is a separator.
Private Function NormalizeRef(ByVal s As String) As String
    Dim i As Long, c As Long, out As String, lastSpace As Boolean
    For i = 1 To Len(s)
        c = AscW(Mid$(s, i, 1))
        If c < 0 Then c = c + 65536
        If (c >= &H5D0 And c <= &H5EA) Or (c >= 48 And c <= 57) Then
            out = out & Mid$(s, i, 1)
            lastSpace = False
        ElseIf (c >= &H591 And c <= &H5BD) Or (c >= &H5BF And c <= &H5C7) Or c = 34 Or c = 39 Or c = &H5F3 Or c = &H5F4 _
               Or c = &H201C Or c = &H201D Or c = &H2018 Or c = &H2019 Or c = &H200E Or c = &H200F Then
            ' ignored
        ElseIf Not lastSpace Then
            out = out & " "
            lastSpace = True
        End If
    Next i
    NormalizeRef = Trim$(out)
End Function

' Chapter / verse number from digits or from a Hebrew numeral (1-176). 0 = not a number.
Private Function RefNumber(ByVal tok As String) As Long
    Dim i As Long, v As Long, prev As Long, total As Long, c As Long
    If Len(tok) = 0 Then Exit Function
    c = AscW(Mid$(tok, 1, 1))
    If c >= 48 And c <= 57 Then
        If IsNumeric(tok) Then
            If Len(tok) <= 3 Then RefNumber = CLng(tok)
        End If
        Exit Function
    End If
    If Len(tok) > 4 Then Exit Function
    prev = 100000
    For i = 1 To Len(tok)
        v = HebLetterValue(AscW(Mid$(tok, i, 1)))
        If v = 0 Or v >= prev Then Exit Function
        total = total + v
        prev = v
    Next i
    If total >= 1 And total <= 176 Then RefNumber = total
End Function

Private Function HebLetterValue(ByVal c As Long) As Long
    If c < 0 Then c = c + 65536
    Select Case c
        Case &H5D0 To &H5D9: HebLetterValue = c - &H5D0 + 1          ' alef..yod = 1..10
        Case &H5DB: HebLetterValue = 20
        Case &H5DC: HebLetterValue = 30
        Case &H5DE: HebLetterValue = 40
        Case &H5E0: HebLetterValue = 50
        Case &H5E1: HebLetterValue = 60
        Case &H5E2: HebLetterValue = 70
        Case &H5E4: HebLetterValue = 80
        Case &H5E6: HebLetterValue = 90
        Case &H5E7: HebLetterValue = 100
        Case &H5E8: HebLetterValue = 200
        Case &H5E9: HebLetterValue = 300
        Case &H5EA: HebLetterValue = 400
        Case Else: HebLetterValue = 0                                ' final letters and others
    End Select
End Function

' Name (book or parasha) -> book name as written in the data file. "" when unknown.
Private Function BookOfAlias(ByVal nm As String) As String
    Dim map As String, p As Long, q As Long
    map = "|" & RefMap()
    p = InStr(1, map, "|" & nm & "=", vbBinaryCompare)
    If p = 0 Then Exit Function
    p = p + Len(nm) + 2
    q = InStr(p, map, "|")
    BookOfAlias = Mid$(map, p, q - p)
End Function

Private Function RefMap() As String
    Dim s As String
    s = s & "בראשית=בראשית|שמות=שמות|ויקרא=ויקרא|במדבר=במדבר|דברים=דברים|יהושע=יהושע|שופטים=שופטים|שמואל א=שמואל א|שמואל ב=שמואל ב|מלכים א=מלכים א|מלכים ב=מלכים ב|ישעיהו=ישעיהו|ירמיהו=ירמיהו|יחזקאל=יחזקאל|הושע=הושע|יואל=יואל|עמוס=עמוס|עובדיה=עובדיה|יונה=יונה|מיכה=מיכה|נחום=נחום|חבקוק=חבקוק|צפניה=צפניה|חגי=חגי|זכריה=זכריה|מלאכי=מלאכי|תהילים=תהילים|משלי=משלי|איוב=איוב|שיר השירים=שיר השירים|רות=רות|איכה=איכה|קהלת=קהלת|אסתר=אסתר|דניאל=דניאל|עזרא=עזרא|נחמיה=נחמיה|דברי הימים א=דברי הימים א|דברי הימים ב=דברי הימים ב|תהלים=תהילים|ישעיה=ישעיהו|ירמיה=ירמיהו|שמואל=שמואל א|מלכים=מלכים א|דברי הימים=דברי הימים א|דהי=דברי הימים א|שה=שיר השירים|נח=בראשית|לך לך=בראשית|וירא=בראשית|חיי שרה=בראשית|תולדות=בראשית|ויצא=בראשית|"
    s = s & "וישלח=בראשית|וישב=בראשית|מקץ=בראשית|ויגש=בראשית|ויחי=בראשית|וארא=שמות|בא=שמות|בשלח=שמות|יתרו=שמות|משפטים=שמות|תרומה=שמות|תצוה=שמות|כי תשא=שמות|ויקהל=שמות|פקודי=שמות|ויקהל פקודי=שמות|צו=ויקרא|שמיני=ויקרא|תזריע=ויקרא|מצורע=ויקרא|אחרי מות=ויקרא|קדושים=ויקרא|אמור=ויקרא|בהר=ויקרא|בחוקותי=ויקרא|תזריע מצורע=ויקרא|אחרי מות קדושים=ויקרא|בהר בחוקותי=ויקרא|נשא=במדבר|בהעלותך=במדבר|שלח=במדבר|שלח לך=במדבר|קרח=במדבר|חקת=במדבר|בלק=במדבר|פינחס=במדבר|מטות=במדבר|מסעי=במדבר|חקת בלק=במדבר|מטות מסעי=במדבר|ואתחנן=דברים|עקב=דברים|ראה=דברים|שפטים=דברים|כי תצא=דברים|כי תבוא=דברים|נצבים=דברים|וילך=דברים|האזינו=דברים|וזאת הברכה=דברים|נצבים וילך=דברים|"
    RefMap = s
End Function

' Shows the verse and offers to insert it into the document.
Private Sub ShowVerse(ByVal picked As Long)
    Dim shown As String, txt As String, sep As String
    Dim a As Long, z As Long, i As Long, r As VbMsgBoxResult
    Const OPT As Long = vbQuestion + vbMsgBoxRtlReading + vbMsgBoxRight

    shown = mRefs(picked) & vbCrLf & vbCrLf & mFull(picked)
    If Len(shown) > 700 Then shown = Left$(shown, 700) & " ..."
    r = MsgBox(shown & vbCrLf & vbCrLf & _
               "כן = להכניס את הפסוק למסמך" & vbCrLf & _
               "לא = להכניס את כל הפרק" & vbCrLf & _
               "ביטול = לסגור", vbYesNoCancel + OPT, "חיפוש פסוק")
    If r = vbYes Then
        InsertIntoDocument mFull(picked)
    ElseIf r = vbNo Then
        ChapterBounds picked, a, z
        r = MsgBox("להכניס את כל הפרק: " & ChapterLabel(picked) & " (" & (z - a + 1) & " פסוקים)" & vbCrLf & vbCrLf & _
                   "כן = כל פסוק בשורה נפרדת" & vbCrLf & _
                   "לא = כל הפסוקים ברצף אחד" & vbCrLf & _
                   "ביטול = לסגור", vbYesNoCancel + OPT, "חיפוש פסוק")
        If r = vbCancel Then Exit Sub
        If r = vbYes Then sep = vbCr Else sep = " "
        For i = a To z
            If i > a Then txt = txt & sep
            txt = txt & mFull(i)
        Next i
        InsertIntoDocument txt
    End If
End Sub

Private Sub InsertIntoDocument(ByVal txt As String)
    If Selection.Type = wdSelectionIP Then
        Selection.TypeText txt
    Else
        Selection.Range.Text = txt
    End If
End Sub

' First / last verse (index) of the chapter that contains verse "idx". References look like "בראשית 32:4".
Private Sub ChapterBounds(ByVal idx As Long, ByRef a As Long, ByRef z As Long)
    Dim pre As String
    pre = Left$(mRefs(idx), InStrRev(mRefs(idx), ":"))
    a = idx
    Do While a > 1
        If Left$(mRefs(a - 1), Len(pre)) <> pre Then Exit Do
        a = a - 1
    Loop
    z = idx
    Do While z < mCount
        If Left$(mRefs(z + 1), Len(pre)) <> pre Then Exit Do
        z = z + 1
    Loop
End Sub

Private Function ChapterLabel(ByVal idx As Long) As String
    ChapterLabel = Left$(mRefs(idx), InStrRev(mRefs(idx), ":") - 1)
End Function

' ---------------------------------------------------------------- search helpers
Private Function VerseAt(ByVal pos As Long) As Long
    ' index of the verse that contains character position pos of the corpus
    Dim lo As Long, hi As Long, mid As Long
    lo = 1
    hi = mCount
    Do While lo < hi
        mid = (lo + hi + 1) \ 2
        If mStart(mid) <= pos Then
            lo = mid
        Else
            hi = mid - 1
        End If
    Loop
    VerseAt = lo
End Function
Private Function FindByEnds(ByVal S As String, ByRef a As Long, ByRef b As Long) As Boolean
    ' Fallback: match only the first 3 and last 3 words of the selection.
    Dim w() As String
    Dim n As Long, p As Long, q As Long, tries As Long, limit As Long
    Dim head As String, tail As String
    w = Split(S, " ")
    n = UBound(w) + 1
    If n < 6 Then Exit Function
    head = w(0) & " " & w(1) & " " & w(2)
    tail = w(n - 3) & " " & w(n - 2) & " " & w(n - 1)
    limit = Len(S) * 2 + 200
    p = InStr(1, mCorpus, head, vbBinaryCompare)
    Do While p > 0 And tries < 50
        tries = tries + 1
        q = InStr(p + 1, mCorpus, tail, vbBinaryCompare)
        If q > 0 And q - p < limit Then
            a = VerseAt(p)
            b = VerseAt(q + Len(tail) - 1)
            If b >= a And b - a < 500 Then
                FindByEnds = True
                Exit Function
            End If
        End If
        p = InStr(p + 1, mCorpus, head, vbBinaryCompare)
    Loop
End Function
Private Function RangeLabel(ByVal a As Long, ByVal b As Long) As String
    If a = b Then
        RangeLabel = mRefs(a)
    Else
        RangeLabel = mRefs(a) & " - " & mRefs(b)
    End If
End Function
Private Function JoinVerses(ByVal a As Long, ByVal b As Long) As String
    Dim parts() As String
    Dim i As Long
    ReDim parts(0 To b - a)
    For i = a To b
        parts(i - a) = mFull(i)
    Next i
    JoinVerses = Join(parts, " ")
End Function
Private Function PickHit(hitA() As Long, hitB() As Long, ByVal n As Long, ByRef chosenA As Long, ByRef chosenB As Long) As Boolean
    Dim msg As String, ans As String
    Dim i As Long, num As Long
    msg = "Several places match. Type the number:" & vbCrLf & vbCrLf
    For i = 1 To n
        msg = msg & i & ") " & RangeLabel(hitA(i), hitB(i)) & "   " & Left$(mFull(hitA(i)), 40) & vbCrLf
    Next i
    ans = InputBox(msg, "Choose passage", "1")
    If Not IsNumeric(ans) Then Exit Function
    num = CLng(ans)
    If num >= 1 And num <= n Then
        chosenA = hitA(num)
        chosenB = hitB(num)
        PickHit = True
    End If
End Function
Private Function StripToLetters(ByVal s As String) As String
    ' Keeps only Hebrew letters; maqaf, spaces and dashes become single spaces.
    Dim i As Long, code As Long
    Dim out As String, lastSpace As Boolean
    For i = 1 To Len(s)
        code = AscW(Mid$(s, i, 1))
        If code < 0 Then code = code + 65536
        If code >= &H5D0 And code <= &H5EA Then
            out = out & ChrW(code)
            lastSpace = False
        ElseIf code <= 32 Or code = 160 Or code = 45 Or code = &H5BE Or (code >= &H2010 And code <= &H2015) Then
            If Len(out) > 0 And Not lastSpace Then
                out = out & " "
                lastSpace = True
            End If
        End If
    Next i
    StripToLetters = Trim$(out)
End Function
' ---------------------------------------------------------------- data file
Private Function EnsureData() As Boolean
    Dim path As String, txt As String, ln As String
    Dim st As Object
    Dim lines() As String, stripped() As String
    Dim n As Long, i As Long, cnt As Long, p1 As Long, p2 As Long, pos As Long
    If mLoaded Then
        EnsureData = True
        Exit Function
    End If
    path = FindDataFile()
    If Len(path) = 0 Then Exit Function
    Application.StatusBar = "Loading Tanakh..."
    Set st = CreateObject("ADODB.Stream")
    st.Type = 2
    st.Charset = "utf-8"
    st.Open
    st.LoadFromFile path
    txt = st.ReadText(-1)
    st.Close
    lines = Split(txt, vbLf)
    n = UBound(lines) + 1
    ReDim mRefs(1 To n)
    ReDim mFull(1 To n)
    ReDim mStart(1 To n)
    ReDim stripped(1 To n)
    For i = 0 To n - 1
        ln = lines(i)
        p1 = InStr(1, ln, vbTab)
        If p1 > 0 Then
            p2 = InStr(p1 + 1, ln, vbTab)
            If p2 > 0 Then
                cnt = cnt + 1
                mRefs(cnt) = Left$(ln, p1 - 1)
                stripped(cnt) = Mid$(ln, p1 + 1, p2 - p1 - 1)
                If Right$(ln, 1) = vbCr Then
                    mFull(cnt) = Mid$(ln, p2 + 1, Len(ln) - p2 - 1)
                Else
                    mFull(cnt) = Mid$(ln, p2 + 1)
                End If
            End If
        End If
    Next i
    If cnt < 1000 Then
        MsgBox "The data file looks wrong or incomplete:" & vbCrLf & path, vbExclamation
        Exit Function
    End If
    ReDim Preserve mRefs(1 To cnt)
    ReDim Preserve mFull(1 To cnt)
    ReDim Preserve mStart(1 To cnt)
    ReDim Preserve stripped(1 To cnt)
    mCount = cnt
    pos = 1
    For i = 1 To cnt
        mStart(i) = pos
        pos = pos + Len(stripped(i)) + 1
    Next i
    mCorpus = Join(stripped, " ")
    mLoaded = True
    EnsureData = True
End Function
Private Function FindDataFile() As String
    Dim saved As String, cand As Variant
    saved = GetSetting("VerseVocalizer", "Settings", "DataFile", "")
    If FileOK(saved) Then
        FindDataFile = saved
        Exit Function
    End If
    For Each cand In CandidatePaths()
        If FileOK(CStr(cand)) Then
            FindDataFile = CStr(cand)
            SaveSetting "VerseVocalizer", "Settings", "DataFile", CStr(cand)
            Exit Function
        End If
    Next cand
    MsgBox "Please select the data file " & DATA_NAME & " (it is needed only once).", vbInformation
    saved = PickDataFile()
    If Len(saved) > 0 Then
        SaveSetting "VerseVocalizer", "Settings", "DataFile", saved
        FindDataFile = saved
    End If
End Function
Private Function CandidatePaths() As Variant
    Dim ownPath As String, docPath As String, startPath As String
    On Error Resume Next
    ownPath = ThisDocument.Path                       ' folder of this template (e.g. Word STARTUP)
    docPath = ActiveDocument.Path
    startPath = Options.DefaultFilePath(8)            ' 8 = wdStartupPath
    On Error GoTo 0
    CandidatePaths = Array( _
        ownPath & "\" & DATA_NAME, _
        startPath & "\" & DATA_NAME, _
        Environ("APPDATA") & "\Microsoft\Word\STARTUP\" & DATA_NAME, _
        docPath & "\" & DATA_NAME, _
        Environ("APPDATA") & "\VerseVocalizer\" & DATA_NAME, _
        Environ("USERPROFILE") & "\Documents\" & DATA_NAME, _
        Environ("USERPROFILE") & "\Downloads\" & DATA_NAME)
End Function
Private Function PickDataFile() As String
    With Application.FileDialog(3)          ' msoFileDialogFilePicker
        .Title = "Select " & DATA_NAME
        .AllowMultiSelect = False
        .Filters.Clear
        .Filters.Add "Text files", "*.txt"
        If .Show = -1 Then PickDataFile = .SelectedItems(1)
    End With
End Function
Private Function FileOK(ByVal p As String) As Boolean
    On Error Resume Next
    If Len(p) > 1 Then FileOK = (Len(Dir(p)) > 0)
    If Err.Number <> 0 Then FileOK = False
End Function
