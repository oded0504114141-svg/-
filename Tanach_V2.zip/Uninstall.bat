@echo off
tasklist /FI "IMAGENAME eq WINWORD.EXE" | find /I "WINWORD.EXE" >nul
if not errorlevel 1 (
  echo Please close Word and run again.
  pause
  exit /b 1
)
del "%APPDATA%\Microsoft\Word\STARTUP\TanachTools.dotm" 2>nul
echo Uninstalled. (The data file tanakh.txt was left in place because the Nikud toolbar may use it.)
pause
