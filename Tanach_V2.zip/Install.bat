@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1"
echo.
echo Log file: %TEMP%\TanachInstall.log
pause
