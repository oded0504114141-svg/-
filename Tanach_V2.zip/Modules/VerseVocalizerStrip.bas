Attribute VB_Name = "VerseVocalizerStrip"
Option Explicit
' GROUP: פסוקים
' ORDER: 5
' Three buttons placed next to "החלף בפסוק מנוקד" (same ribbon group):
'   delete nikud only / delete taamim only / delete both.
' They work on the selection, or on the whole document when nothing is selected (after a confirmation).
' Letters, fonts and colors are not changed - only the marks are removed. Ctrl+Z undoes it in one step.
'
'   Nikud   : U+05B0-05BC (vowels, dagesh), U+05BF (rafe), U+05C1-05C2 (shin / sin dots), U+05C7 (kamatz katan)
'   Taamim  : U+0591-05AF (cantillation), U+05BD (meteg), U+05C4-05C5 (extraordinary points)
'   Kept    : maqaf (05BE), paseq (05C0), sof pasuq (05C3)

' Parasha names (without nikud), longest first. A space inside a name matches one or more spaces.
Private Const PARASHOT As String = "אחרי מות קדושים|בהר בחוקותי|ויקהל פקודי|תזריע מצורע|וזאת הברכה|נצבים וילך|מטות מסעי|אחרי מות|בהעלותך|בחוקותי|חיי שרה|חקת בלק|כי תבוא|בראשית|האזינו|ואתחנן|כי תצא|כי תשא|משפטים|קדושים|שלח לך|תולדות|במדבר|דברים|ויקהל|ויקרא|וישלח|לך לך|מצורע|נצבים|פינחס|פקודי|שמיני|שפטים|תזריע|תרומה|אמור|בשלח|וארא|ויגש|ויחי|וילך|ויצא|וירא|וישב|יתרו|מטות|מסעי|שמות|תצוה|בהר|בלק|חקת|מקץ|נשא|עקב|קרח|ראה|שלח|בא|נח|צו"

' BUTTON: מחק ניקוד
' ICON: ClearFormatting
Public Sub DeleteNikudOnly()
    StripMarks True, False
End Sub

' BUTTON: מחק טעמים
' ICON: ClearFormatting
Public Sub DeleteTaamimOnly()
    StripMarks False, True
End Sub

' BUTTON: מחק ניקוד וטעמים
' ICON: ClearFormatting
Public Sub DeleteNikudAndTaamim()
    StripMarks True, True
End Sub

' Deletes chapter / verse number markers that sit inside vocalized text. The markers are usually plain letters
' (no nikud, no taamim), for example:  (א)   [י"ב]   {ג}   (בראשית א, ב)   פרק ב   ט"ו   12   1:2
'   1. Anything in ( ) [ ] { } that holds only plain letters / digits / , . : ' " - and spaces.
'   2. "פרק"/"פסוק" + numeral and "פרשת" + parasha name (e.g. פרשת וישלח), in any paragraph (a paragraph left empty by this is removed).
'   3. Inside a paragraph that has nikud: a standalone plain-letter Hebrew numeral (1-176) and standalone digits.
' After the markers are removed you choose: verses in one running paragraph, or each verse on its own line.
' Words are never touched: a plain word such as "לא" is not a valid numeral and stays.
' BUTTON: מחק פרק פסוק ופרשה
' ICON: ClearFormatting
Public Sub DeleteVerseNumbers()
    Dim rng As Range
    Dim i As Long
    Dim total As Long
    Dim re As Object
    Dim undoOpen As Boolean
    Dim failed As Boolean
    Dim joinMode As Boolean
    Const TITLE As String = "מחק פרק פסוק ופרשה"

    On Error GoTo Fail

    If Selection.Type = wdSelectionIP Then
        If MsgBox("לא נבחר טקסט. לבצע את הפעולה על כל המסמך?", _
                  vbYesNo + vbQuestion + vbMsgBoxRtlReading + vbMsgBoxRight, TITLE) <> vbYes Then Exit Sub
        Set rng = ActiveDocument.Content
    Else
        Set rng = Selection.Range.Duplicate
    End If

    ' how to leave the verses after the markers are gone
    Select Case MsgBox("אחרי מחיקת הסימונים, איך להציג את הפסוקים?" & vbCrLf & vbCrLf & _
                       "כן = ברצף אחד (פסוק אחרי פסוק באותה פסקה)" & vbCrLf & _
                       "לא = כל פסוק בשורה נפרדת (כמו שהם עכשיו)" & vbCrLf & _
                       "ביטול = לבטל את הפעולה", _
                       vbYesNoCancel + vbQuestion + vbMsgBoxRtlReading + vbMsgBoxRight, TITLE)
        Case vbYes: joinMode = True
        Case vbNo: joinMode = False
        Case Else: Exit Sub
    End Select

    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = False
    re.MultiLine = False

    Application.ScreenUpdating = False
    Application.UndoRecord.StartCustomRecord TITLE
    undoOpen = True

    For i = rng.Paragraphs.Count To 1 Step -1
        total = total + StripNumbersInParagraph(rng, i, re)
    Next i
    If joinMode Then
        JoinParagraphs rng
        For i = rng.Paragraphs.Count To 1 Step -1
            CollapseSpaces rng, i
        Next i
    End If

Done:
    If undoOpen Then Application.UndoRecord.EndCustomRecord
    Application.ScreenUpdating = True
    If Not failed Then
        If total = 0 Then
            MsgBox "לא נמצאו סימוני פרק, פסוק או פרשה למחיקה.", vbInformation + vbMsgBoxRtlReading + vbMsgBoxRight, TITLE
        Else
            MsgBox "נמחקו " & total & " סימונים.", vbInformation + vbMsgBoxRtlReading + vbMsgBoxRight, TITLE
        End If
    End If
    Exit Sub

Fail:
    failed = True
    MsgBox "Error: " & CStr(Err.Number) & " - " & Err.Description, vbCritical
    Resume Done
End Sub

Private Sub StripMarks(ByVal doNikud As Boolean, ByVal doTaamim As Boolean)
    Dim rng As Range
    Dim i As Long
    Dim title As String
    Dim undoOpen As Boolean
    Dim failed As Boolean

    On Error GoTo Fail

    If doNikud And doTaamim Then
        title = "מחק ניקוד וטעמים"
    ElseIf doNikud Then
        title = "מחק ניקוד"
    Else
        title = "מחק טעמים"
    End If

    If Selection.Type = wdSelectionIP Then
        If MsgBox("לא נבחר טקסט. לבצע את הפעולה על כל המסמך?", _
                  vbYesNo + vbQuestion + vbMsgBoxRtlReading + vbMsgBoxRight, title) <> vbYes Then Exit Sub
        Set rng = ActiveDocument.Content
    Else
        Set rng = Selection.Range.Duplicate
    End If

    Application.ScreenUpdating = False
    Application.UndoRecord.StartCustomRecord title
    undoOpen = True

    ' מהפסקה האחרונה אל הראשונה, כדי שמחיקות לא יזיזו את המיקומים שעוד לא טופלו
    For i = rng.Paragraphs.Count To 1 Step -1
        StripParagraph rng, i, doNikud, doTaamim
    Next i

Done:
    If undoOpen Then Application.UndoRecord.EndCustomRecord
    Application.ScreenUpdating = True
    If Not failed Then
        MsgBox "בוצע: " & title & ".", vbInformation + vbMsgBoxRtlReading + vbMsgBoxRight, title
    End If
    Exit Sub

Fail:
    failed = True
    MsgBox "Error: " & CStr(Err.Number) & " - " & Err.Description, vbCritical
    Resume Done
End Sub

' Deletes the marks inside one paragraph of rng. The text is scanned here (not with Word's Find, which can
' ignore diacritics and so would treat nikud and taamim as the same thing), and each run of marks is checked
' against the document before it is deleted.
Private Sub StripParagraph(ByVal rng As Range, ByVal idx As Long, ByVal doNikud As Boolean, ByVal doTaamim As Boolean)
    Dim doc As Document
    Dim a As Long, z As Long
    Dim txt As String
    Dim i As Long, j As Long
    Dim runText As String

    Set doc = rng.Document
    With rng.Paragraphs(idx).Range
        a = .Start: z = .End
    End With
    If a < rng.Start Then a = rng.Start
    If z > rng.End Then z = rng.End
    If z <= a Then Exit Sub

    txt = doc.Range(a, z).Text
    i = Len(txt)
    Do While i >= 1
        If IsTargetMark(AscW(Mid$(txt, i, 1)), doNikud, doTaamim) Then
            j = i
            Do While j > 1
                If Not IsTargetMark(AscW(Mid$(txt, j - 1, 1)), doNikud, doTaamim) Then Exit Do
                j = j - 1
            Loop
            runText = Mid$(txt, j, i - j + 1)
            If doc.Range(a + j - 1, a + i).Text = runText Then doc.Range(a + j - 1, a + i).Delete
            i = j - 1
        Else
            i = i - 1
        End If
    Loop
End Sub

Private Function IsTargetMark(ByVal code As Long, ByVal doNikud As Boolean, ByVal doTaamim As Boolean) As Boolean
    If code < 0 Then code = code + 65536
    If doTaamim Then
        If (code >= &H591 And code <= &H5AF) Or code = &H5BD Or code = &H5C4 Or code = &H5C5 Then IsTargetMark = True: Exit Function
    End If
    If doNikud Then
        If (code >= &H5B0 And code <= &H5BC) Or code = &H5BF Or code = &H5C1 Or code = &H5C2 Or code = &H5C7 Then IsTargetMark = True
    End If
End Function

' ---------------------------------------------------------------------------------------------
' Verse / chapter numbers
' ---------------------------------------------------------------------------------------------

' Runs the 4 patterns on one paragraph of rng and returns how many markers were deleted.
' Joins all the paragraphs of rng into one running text: every paragraph mark (except the last one of rng)
' becomes a single space; empty paragraphs are removed. Table cells are left alone.
Private Sub JoinParagraphs(ByVal rng As Range)
    Dim doc As Document
    Dim i As Long, a As Long, z As Long
    Dim pr As Range
    Dim before As String, after As String

    Set doc = rng.Document
    For i = rng.Paragraphs.Count - 1 To 1 Step -1
        Set pr = rng.Paragraphs(i).Range
        a = pr.Start: z = pr.End
        If pr.Information(wdWithInTable) Then GoTo NextPara
        If z - a <= 1 Then
            ' empty paragraph: remove it
            If doc.Range(a, z).Text = vbCr Then doc.Range(a, z).Delete
        ElseIf doc.Range(z - 1, z).Text = vbCr Then
            before = doc.Range(z - 2, z - 1).Text
            after = doc.Range(z, z + 1).Text
            If before = " " Or after = " " Then
                doc.Range(z - 1, z).Delete          ' there is already a space: just remove the mark
            Else
                doc.Range(z - 1, z).Text = " "      ' the mark becomes one space
            End If
        End If
NextPara:
    Next i
End Sub

Private Function StripNumbersInParagraph(ByVal rng As Range, ByVal idx As Long, ByVal re As Object) As Long
    Dim hasNikud As Boolean
    Dim pass As Long
    Dim cnt As Long

    hasNikud = ParagraphHasNikud(rng, idx)
    For pass = 1 To 5
        ' brackets, "perek / pasuk + numeral" and "parashat + name" are explicit markers: removed from any paragraph
        If pass = 1 Or pass = 3 Or pass = 5 Or hasNikud Then cnt = cnt + StripNumbersPass(rng, idx, re, pass)
    Next pass
    If cnt > 0 Then
        CollapseSpaces rng, idx          ' no gap is left where a marker was removed
        DeleteParagraphIfEmpty rng, idx
    End If
    StripNumbersInParagraph = cnt
End Function

' Removes the gap a deleted marker leaves behind: every run of spaces (space, no-break space, tab, with or without
' invisible direction marks between them) becomes ONE space, and spaces at the start / end of the paragraph go.
Private Sub CollapseSpaces(ByVal rng As Range, ByVal idx As Long)
    Dim doc As Document
    Dim a As Long, z As Long, n As Long
    Dim txt As String, runText As String
    Dim i As Long, j As Long, spaces As Long, k As Long

    If Not ParagraphBounds(rng, idx, a, z) Then Exit Sub
    Set doc = rng.Document
    txt = doc.Range(a, z).Text
    n = Len(txt)
    Do While n > 0
        If Mid$(txt, n, 1) = vbCr Or AscW(Mid$(txt, n, 1)) = 7 Then n = n - 1 Else Exit Do
    Loop
    If n = 0 Then Exit Sub

    i = n
    Do While i >= 1
        If IsGapChar(Mid$(txt, i, 1)) Then
            j = i
            Do While j > 1
                If Not IsGapChar(Mid$(txt, j - 1, 1)) Then Exit Do
                j = j - 1
            Loop
            runText = Mid$(txt, j, i - j + 1)
            spaces = 0
            For k = 1 To Len(runText)
                If IsSpaceChar(Mid$(runText, k, 1)) Then spaces = spaces + 1
            Next k
            If spaces > 0 Then
                If doc.Range(a + j - 1, a + i).Text = runText Then
                    If j = 1 Or i = n Then
                        doc.Range(a + j - 1, a + i).Delete              ' start / end of the paragraph
                    ElseIf spaces > 1 Then
                        doc.Range(a + j - 1, a + i).Text = " "          ' several spaces become one
                    End If
                End If
            End If
            i = j - 1
        Else
            i = i - 1
        End If
    Loop
End Sub

Private Function IsSpaceChar(ByVal ch As String) As Boolean
    Dim c As Long
    c = AscW(ch): If c < 0 Then c = c + 65536
    IsSpaceChar = (c = 32 Or c = 160 Or c = 9)
End Function

' space-like characters plus invisible direction marks (they can sit between two spaces)
Private Function IsGapChar(ByVal ch As String) As Boolean
    Dim c As Long
    c = AscW(ch): If c < 0 Then c = c + 65536
    IsGapChar = (c = 32 Or c = 160 Or c = 9 Or c = &H200E Or c = &H200F)
End Function

' After the markers were removed, a paragraph that holds nothing else (e.g. a heading that was only "פרק לב")
' is deleted together with its paragraph mark, so no empty line is left behind.
Private Sub DeleteParagraphIfEmpty(ByVal rng As Range, ByVal idx As Long)
    Dim a As Long, z As Long, txt As String, i As Long, c As Long
    If idx > rng.Paragraphs.Count Then Exit Sub
    With rng.Paragraphs(idx).Range
        a = .Start: z = .End
    End With
    txt = rng.Document.Range(a, z).Text
    For i = 1 To Len(txt)
        c = AscW(Mid$(txt, i, 1))
        If c < 0 Then c = c + 65536
        If Not (c = 13 Or c = 7 Or c = 32 Or c = 9 Or c = &HA0 Or c = 11) Then Exit Sub   ' something is left
    Next i
    If InStr(txt, Chr(7)) > 0 Then Exit Sub        ' table cell: keep the cell
    On Error Resume Next
    rng.Document.Range(a, z).Delete
    On Error GoTo 0
End Sub

Private Function ParagraphHasNikud(ByVal rng As Range, ByVal idx As Long) As Boolean
    Dim a As Long, z As Long, txt As String, i As Long, c As Long
    If Not ParagraphBounds(rng, idx, a, z) Then Exit Function
    txt = rng.Document.Range(a, z).Text
    For i = 1 To Len(txt)
        c = AscW(Mid$(txt, i, 1))
        If c < 0 Then c = c + 65536
        If c >= &H5B0 And c <= &H5C7 Then ParagraphHasNikud = True: Exit Function
    Next i
End Function

' Start / end of paragraph idx, limited to rng. False when the paragraph is empty.
Private Function ParagraphBounds(ByVal rng As Range, ByVal idx As Long, ByRef a As Long, ByRef z As Long) As Boolean
    If idx > rng.Paragraphs.Count Then Exit Function
    With rng.Paragraphs(idx).Range
        a = .Start: z = .End
    End With
    If a < rng.Start Then a = rng.Start
    If z > rng.End Then z = rng.End
    ParagraphBounds = (z > a)
End Function


Private Function StripNumbersPass(ByVal rng As Range, ByVal idx As Long, ByVal re As Object, ByVal pass As Long) As Long
    Const HEB As String = "\u05D0-\u05EA"
    Const Q As String = "\""'\u05F3\u05F4\u201C\u201D\u2018\u2019"
    Dim doc As Document
    Dim a As Long, z As Long
    Dim txt As String
    Dim n As Long
    Dim ms As Object, m As Object
    Dim starts() As Long, ends() As Long
    Dim cnt As Long, k As Long
    Dim s As Long, e As Long
    Dim g1 As String, core As String, tok As String, tail As String

    If Not ParagraphBounds(rng, idx, a, z) Then Exit Function
    Set doc = rng.Document
    txt = doc.Range(a, z).Text
    n = Len(txt)
    Do While n > 0
        If Mid$(txt, n, 1) = vbCr Or AscW(Mid$(txt, n, 1)) = 7 Then n = n - 1 Else Exit Do
    Loop
    If n = 0 Then Exit Function
    txt = Left$(txt, n)

    Select Case pass
        Case 1   ' anything in brackets made only of plain letters / digits / punctuation
            re.Pattern = "( ?)([\(\[\{][" & HEB & "0-9 ,.:;\-\u2013\u05BE" & Q & "]{1,40}[\)\]\}])( ?)"
        Case 2   ' standalone Hebrew numeral
            re.Pattern = "(^| )([" & HEB & Q & "]{1,6})([,.:]?)(?= |$)"
        Case 3   ' "perek" / "pasuk" + numeral
            re.Pattern = "( ?)((?:\u05E4\u05E8\u05E7|\u05E4\u05E1\u05D5\u05E7) +([" & HEB & Q & "]{1,6})[,.:]?)(?= |$)"
        Case 5   ' "parashat" + parasha name
            re.Pattern = "( ?)(\u05E4\u05E8\u05E9\u05EA +(?:" & Replace(PARASHOT, " ", " +") & ")[,.:]?)(?= |$)"
        Case Else ' standalone digits
            re.Pattern = "(^| )(\d{1,3}(?:[:.,]\d{1,3})?)([.:]?)(?= |$)"
    End Select

    Set ms = re.Execute(txt)
    If ms.Count = 0 Then Exit Function
    ReDim starts(1 To ms.Count): ReDim ends(1 To ms.Count)

    For Each m In ms
        g1 = m.SubMatches(0)
        ' validate the numeral where the pattern alone is not enough
        If pass = 2 Then
            If Not IsHebrewNumeral(m.SubMatches(1)) Then GoTo NextMatch
        ElseIf pass = 3 Then
            If Not IsHebrewNumeral(m.SubMatches(2)) Then GoTo NextMatch
        End If

        s = m.FirstIndex + 1                       ' first character of the whole match (the optional space)
        e = m.FirstIndex + m.Length                ' last character of the whole match
        If pass = 1 Then
            ' the whole match is  [space] marker [space]: keep one space between the words
            If Len(g1) = 1 Then
                e = e - Len(m.SubMatches(2))       ' remove the space before + marker, keep the one after
            End If
        ElseIf pass = 2 Or pass = 4 Then
            If Len(g1) = 0 Then
                If e < n Then If Mid$(txt, e + 1, 1) = " " Then e = e + 1   ' marker at the start: remove the space after it
            End If
        Else
            If Len(g1) = 0 Then
                If e < n Then If Mid$(txt, e + 1, 1) = " " Then e = e + 1
            End If
        End If

        cnt = cnt + 1
        starts(cnt) = s: ends(cnt) = e
NextMatch:
    Next m

    ' delete from the end of the paragraph to its start so the earlier positions stay valid
    Dim done As Long
    For k = cnt To 1 Step -1
        If doc.Range(a + starts(k) - 1, a + ends(k)).Text = Mid$(txt, starts(k), ends(k) - starts(k) + 1) Then
            doc.Range(a + starts(k) - 1, a + ends(k)).Delete
            done = done + 1
        End If
    Next k
    StripNumbersPass = done
End Function

' True for a Hebrew numeral from 1 to 176 written with plain letters (optionally with geresh / gershayim):
' letters in descending value, no final letters, up to 4 letters.
Private Function IsHebrewNumeral(ByVal tok As String) As Boolean
    Dim i As Long, v As Long, prev As Long, total As Long, c As Long, ch As String, letters As String

    For i = 1 To Len(tok)
        ch = Mid$(tok, i, 1)
        c = AscW(ch): If c < 0 Then c = c + 65536
        Select Case c
            Case 34, 39, &H5F3, &H5F4, &H201C, &H201D, &H2018, &H2019
                ' quote marks are ignored
            Case Else
                letters = letters & ch
        End Select
    Next i
    If Len(letters) = 0 Or Len(letters) > 4 Then Exit Function

    prev = 100000
    For i = 1 To Len(letters)
        v = LetterValue(AscW(Mid$(letters, i, 1)))
        If v = 0 Or v >= prev Then Exit Function
        total = total + v
        prev = v
    Next i
    IsHebrewNumeral = (total >= 1 And total <= 176)
End Function

Private Function LetterValue(ByVal c As Long) As Long
    If c < 0 Then c = c + 65536
    Select Case c
        Case &H5D0: LetterValue = 1     ' alef
        Case &H5D1: LetterValue = 2
        Case &H5D2: LetterValue = 3
        Case &H5D3: LetterValue = 4
        Case &H5D4: LetterValue = 5
        Case &H5D5: LetterValue = 6
        Case &H5D6: LetterValue = 7
        Case &H5D7: LetterValue = 8
        Case &H5D8: LetterValue = 9
        Case &H5D9: LetterValue = 10
        Case &H5DB: LetterValue = 20
        Case &H5DC: LetterValue = 30
        Case &H5DE: LetterValue = 40
        Case &H5E0: LetterValue = 50
        Case &H5E1: LetterValue = 60
        Case &H5E2: LetterValue = 70
        Case &H5E4: LetterValue = 80
        Case &H5E6: LetterValue = 90
        Case &H5E7: LetterValue = 100
        Case &H5E8: LetterValue = 200
        Case &H5E9: LetterValue = 300
        Case &H5EA: LetterValue = 400
        Case Else: LetterValue = 0      ' final letters and everything else
    End Select
End Function
