﻿# התקנת סרגל "תנ""ך" ב-Word - לחצן לכל מאקרו מכל קבצי ה-bas שבתיקיית Modules
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

function Show-Msg($text, $icon) {
    $rtl = [System.Windows.Forms.MessageBoxOptions]::RtlReading -bor [System.Windows.Forms.MessageBoxOptions]::RightAlign
    [void][System.Windows.Forms.MessageBox]::Show($text, 'התקנת סרגל תנ"ך', 'OK', $icon, 'Button1', $rtl)
}

# קריאת קובץ טקסט: UTF-8 (עם/בלי BOM) או Windows-1255
function Read-Text($path) {
    $b = [IO.File]::ReadAllBytes($path)
    if ($b.Length -ge 3 -and $b[0] -eq 0xEF -and $b[1] -eq 0xBB -and $b[2] -eq 0xBF) {
        return [Text.Encoding]::UTF8.GetString($b, 3, $b.Length - 3)
    }
    try { return (New-Object Text.UTF8Encoding($false, $true)).GetString($b) }
    catch { return [Text.Encoding]::GetEncoding(1255).GetString($b) }
}

# בדיקה שהקובץ ששמר Word הוא באמת תבנית עם מאקרו (dotm תקין)
function Test-Dotm($path) {
    try {
        $fs = New-Object IO.FileStream($path, 'Open', 'Read', 'ReadWrite')
        $z = New-Object IO.Compression.ZipArchive($fs, [IO.Compression.ZipArchiveMode]::Read)
        try {
            $names = @($z.Entries | ForEach-Object { $_.FullName })
            $r = New-Object IO.StreamReader($z.GetEntry('[Content_Types].xml').Open())
            $t = $r.ReadToEnd(); $r.Close()
            Write-Host ('  package entries: ' + ($names -join ', '))
            return (($t -match 'macroEnabledTemplate') -and ($names -contains 'word/vbaProject.bin'))
        } finally { $z.Dispose(); $fs.Dispose() }
    } catch { Write-Host ('  could not inspect file: ' + $_.Exception.Message); return $null }
}

$log = Join-Path $env:TEMP 'TanachInstall.log'
try { Start-Transcript -Path $log -Force | Out-Null } catch {}

try {
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
if ($here -match '\\Temp\\Temp\d+_') {
    Show-Msg 'נראה שהקבצים עדיין בתוך קובץ ה-zip. חלצו את כל התיקייה (קליק ימני ← חלץ הכול) והריצו משם.' 'Warning'; exit 1
}
$modDir  = Join-Path $here 'Modules'

# הגדרות (קובץ Settings.ps1): לשונית מארחת
$HostNamespace = ''; $HostTab = ''
$settingsFile = Join-Path $here 'Settings.ps1'
# (בחבילה זו אין Settings.ps1: תמיד לשונית נפרדת אחת בשם תנ"ך)
$startup = Join-Path $env:APPDATA 'Microsoft\Word\STARTUP'
$target  = Join-Path $startup 'TanachTools.dotm'

$files = @()
if (Test-Path $modDir) { $files = @(Get-ChildItem $modDir -Filter *.bas | Sort-Object Name) }
if ($files.Count -eq 0) { Show-Msg 'לא נמצאו קבצי bas בתיקייה Modules.' 'Error'; exit 1 }
if (Get-Process WINWORD -ErrorAction SilentlyContinue) {
    Show-Msg 'Word פתוח. שמרו וסגרו את כל חלונות Word, ואז הריצו שוב את ההתקנה.' 'Warning'; exit 1
}
if (-not (Test-Path $startup)) { New-Item -ItemType Directory -Force $startup | Out-Null }
# קבצי נתונים (תיקייה Data) - מועתקים לתיקיית STARTUP, ליד התבנית
$dataDir = Join-Path $here 'Data'
if (Test-Path $dataDir) {
    foreach ($d in @(Get-ChildItem $dataDir -File)) { Copy-Item $d.FullName (Join-Path $startup $d.Name) -Force; Write-Host ('  data file: ' + $d.Name) }
}
foreach ($f in $target) { if (Test-Path $f) { Remove-Item $f -Force } }

# --- קריאת המודולים וזיהוי הלחצנים ---
# בקובץ bas אפשר לכתוב:
#   ' GROUP: שם הקבוצה בסרגל        (אופציונלי, אחת לקובץ)
#   ' BUTTON: שם הלחצן              (שורה לפני Public Sub ללא פרמטרים)
# אם אין אף BUTTON בקובץ - נוצר לחצן לכל Public Sub ללא פרמטרים.
$modules = @()
foreach ($f in $files) {
    $text  = Read-Text $f.FullName
    $lines = $text -split "`r?`n"
    $name  = [IO.Path]::GetFileNameWithoutExtension($f.Name)
    foreach ($l in $lines) { if ($l -match '^Attribute VB_Name\s*=\s*"([^"]+)"') { $name = $Matches[1]; break } }
    $group = $name; $order = 100; $buttons = @(); $allSubs = @(); $pending = $null; $pIcon = $null; $pSep = $false; $tab = $null
    foreach ($l in $lines) {
        if ($l -match '^\s*\x27\s*TAB:\s*(.+?)\s*$')     { $tab = $Matches[1]; continue }
        if ($l -match '^\s*\x27\s*GROUP:\s*(.+?)\s*$')  { $group = $Matches[1]; continue }
        if ($l -match '^\s*\x27\s*ORDER:\s*(\d+)')        { $order = [int]$Matches[1]; continue }
        if ($l -match '^\s*\x27\s*SEPARATOR\b')         { $pSep = $true; continue }
        if ($l -match '^\s*\x27\s*BUTTON:\s*(.+?)\s*$') { $pending = $Matches[1]; continue }
        if ($l -match '^\s*\x27\s*ICON:\s*(\w+)')        { $pIcon = $Matches[1]; continue }
        if ($l -match '^\s*(Public\s+)?Sub\s+(\w+)\s*\(\s*\)') {
            $s = $Matches[2]; $allSubs += $s
            if ($pending) {
                $ic = 'MacroPlay'; if ($pIcon) { $ic = $pIcon }
                $buttons += [pscustomobject]@{ Sub = $s; Label = $pending; Icon = $ic; Sep = $pSep }
            }
            $pending = $null; $pIcon = $null; $pSep = $false; continue
        }
        if ($l.Trim() -ne '' -and $l -notmatch '^\s*\x27') { $pending = $null; $pSep = $false }
    }
    if ($buttons.Count -eq 0) { foreach ($s in $allSubs) { $buttons += [pscustomobject]@{ Sub = $s; Label = $s; Icon = 'MacroPlay' } } }
    $clean = $lines | Where-Object { $_ -notmatch '^\s*Attribute\s+' -and $_ -notmatch '^\s*Option Explicit' }
    $modules += [pscustomobject]@{
        Name = $name; Group = $group; Tab = $tab; Order = $order; Buttons = $buttons
        Code = "Option Explicit`r`n" + ($clean -join "`r`n")
    }
}

$modules = @($modules | Sort-Object Order, Name)

# --- פונקציה אחת שמריצה את הלחצן לפי ה-Tag שלו ---
$callbackCode = @'
Option Explicit

Public Sub RibbonRun(control As IRibbonControl)
    On Error GoTo Fail
    Application.Run "TanachTools." & control.Tag
    Exit Sub
Fail:
    MsgBox "Error running " & control.Tag & ": " & Err.Description, vbExclamation
End Sub
'@

# --- בניית קובץ הרצועה ---
function X($s) { [Security.SecurityElement]::Escape($s) }
$sb = New-Object Text.StringBuilder
[void]$sb.AppendLine('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>')
$iconDir = Join-Path $here 'Icons'
$imgs = [ordered]@{}   # אייקונים מותאמים (קבצי png) שיוטמעו בתבנית
$groups = [ordered]@{}
$groupTab = @{}        # לשונית מארחת לכל קבוצה (מהשורה ' TAB: של המודול הראשון בקבוצה)
foreach ($m in $modules) {
    foreach ($b in $m.Buttons) {
        if (-not $groups.Contains($m.Group)) { $groups[$m.Group] = New-Object System.Collections.ArrayList; $groupTab[$m.Group] = $m.Tab }
        [void]$groups[$m.Group].Add([pscustomobject]@{ Label = $b.Label; Icon = $b.Icon; Sep = $b.Sep; Tag = ($m.Name + '.' + $b.Sub) })
    }
}
$groupXml = [ordered]@{}
$gi = 0
foreach ($gname in $groups.Keys) {
    $gi++
    $g = New-Object Text.StringBuilder
    [void]$g.AppendLine(('<group id="grp{0}" label="{1}">' -f $gi, (X $gname)))
    $bi = 0
    foreach ($b in $groups[$gname]) {
        $bi++
        if ($b.Sep -and $bi -gt 1) { [void]$g.AppendLine(('<separator id="sep{0}_{1}"/>' -f $gi, $bi)) }
        # אם יש קובץ Icons\<שם>.png משתמשים בו, אחרת בסמל מובנה של Office (imageMso)
        $iconAttr = ('imageMso="' + (X $b.Icon) + '"')
        $png = Join-Path $iconDir ($b.Icon + '.png')
        if (Test-Path $png) { $imgs[$b.Icon] = $png; $iconAttr = 'image="img_' + $b.Icon + '"' }
        [void]$g.AppendLine(('<button id="btn{0}_{1}" label="{2}" size="large" {4} tag="{3}" onAction="RibbonRun"/>' -f $gi, $bi, (X $b.Label), (X $b.Tag), $iconAttr))
    }
    [void]$g.AppendLine('</group>')
    $groupXml[$gname] = $g.ToString()
}
if ($HostTab) {
    # הוספת הקבוצות ללשוניות של תוספים אחרים (idQ + מרחב השמות של כל תוסף)
    $specOf = @{}; $nsList = @(); $keys = @()
    foreach ($gname in $groups.Keys) {
        $spec = $groupTab[$gname]; if (-not $spec) { $spec = $HostTab }
        $bar = $spec.IndexOf('|')
        if ($bar -ge 0) { $ns = $spec.Substring(0, $bar); $id = $spec.Substring($bar + 1) } else { $ns = $HostNamespace; $id = $spec }
        $specOf[$gname] = $ns + '|' + $id
        if ($nsList -notcontains $ns) { $nsList += $ns }
        if ($keys -notcontains $specOf[$gname]) { $keys += $specOf[$gname] }
    }
    $decl = ''
    for ($n = 0; $n -lt $nsList.Count; $n++) { $decl += (' xmlns:h{0}="{1}"' -f $n, (X $nsList[$n])) }
    [void]$sb.AppendLine('<customUI xmlns="http://schemas.microsoft.com/office/2009/07/customui"' + $decl + '><ribbon><tabs>')
    foreach ($k in $keys) {
        $bar = $k.IndexOf('|'); $ns = $k.Substring(0, $bar); $id = $k.Substring($bar + 1)
        [void]$sb.AppendLine(('<tab idQ="h{0}:{1}">' -f [array]::IndexOf($nsList, $ns), (X $id)))
        foreach ($gname in $groups.Keys) { if ($specOf[$gname] -eq $k) { [void]$sb.Append($groupXml[$gname]) } }
        [void]$sb.AppendLine('</tab>')
    }
    [void]$sb.AppendLine('</tabs></ribbon></customUI>')
} else {
    [void]$sb.AppendLine('<customUI xmlns="http://schemas.microsoft.com/office/2009/07/customui"><ribbon><tabs>')
    [void]$sb.AppendLine('<tab id="tabTanachTools" label="תנ&quot;ך" insertAfterMso="TabHome">')
    foreach ($gname in $groups.Keys) { [void]$sb.Append($groupXml[$gname]) }
    [void]$sb.AppendLine('</tab></tabs></ribbon></customUI>')
}
$ribbon = $sb.ToString()

# --- גישה זמנית ל-VBA (נדרש להוספת המודולים) ושחזור בסוף ---
$saved = @{}
foreach ($v in '14.0','15.0','16.0') {
    if (Test-Path "HKCU:\Software\Microsoft\Office\$v") {
        $key = "HKCU:\Software\Microsoft\Office\$v\Word\Security"
        if (-not (Test-Path $key)) { New-Item $key -Force | Out-Null }
        $saved[$key] = (Get-ItemProperty $key -ErrorAction SilentlyContinue).AccessVBOM
        Set-ItemProperty $key -Name AccessVBOM -Value 1 -Type DWord
    }
}

$word = $null
try {
    Write-Host 'Creating template in Word...'
    $word = New-Object -ComObject Word.Application
    $word.Visible = $false
    $word.DisplayAlerts = 0
    $doc = $word.Documents.Add()
    $proj = $doc.VBProject
    $proj.Name = 'TanachTools'   # שם ייחודי לפרויקט, כדי ש-Application.Run לא יחפש גם בתבניות אחרות
    $all = @($modules | ForEach-Object { @{ Name = $_.Name; Code = $_.Code } })
    $all += @{ Name = 'RibbonCallbacks'; Code = $callbackCode }
    foreach ($m in $all) {
        Write-Host ('  module: ' + $m.Name)
        $c = $proj.VBComponents.Add(1)
        $c.Name = $m.Name
        if ($c.CodeModule.CountOfLines -gt 0) { $c.CodeModule.DeleteLines(1, $c.CodeModule.CountOfLines) }
        $c.CodeModule.AddFromString($m.Code)
    }
    $path = [string]$target; $fmt = [int]15   # wdFormatXMLTemplateMacroEnabled = 15 (13 הוא מסמך docm)
    Add-Type -AssemblyName Microsoft.VisualBasic
    $call = [Microsoft.VisualBasic.CallType]::Method
    # כמה דרכים לשמירה - PowerShell ו-COM לא תמיד מסתדרים על הפרמטרים; מנסים אחת אחרי השנייה
    $attempts = @(
        { [void][Microsoft.VisualBasic.Interaction]::CallByName($doc, 'SaveAs2', $call, $path, $fmt) },
        { [void][Microsoft.VisualBasic.Interaction]::CallByName($doc, 'SaveAs', $call, $path, $fmt) },
        { $doc.SaveAs2($path, $fmt) },
        { [object]$p = $path; [object]$f = $fmt; $doc.SaveAs2([ref]$p, [ref]$f) },
        { [object]$p = $path; [object]$f = $fmt; $doc.SaveAs([ref]$p, [ref]$f) }
    )
    $isSaved = $false
    foreach ($a in $attempts) {
        if (Test-Path $path) { Remove-Item $path -Force -ErrorAction SilentlyContinue }
        try { & $a } catch { Write-Host ('  save attempt failed: ' + $_.Exception.Message) }
        if (Test-Path $path) {
            $ok = Test-Dotm $path
            if ($ok -ne $false) { $isSaved = $true; break }
            Write-Host '  saved file is not a macro-enabled template, trying next method'
        }
    }
    if (-not $isSaved) { try { $doc.Close(0) } catch {}; Remove-Item $path -Force -ErrorAction SilentlyContinue; throw 'Word could not save the template file (all save methods failed).' }
    try { $doc.Close(0) } catch {}
}
finally {
    if ($word) { $word.Quit(); [void][Runtime.InteropServices.Marshal]::ReleaseComObject($word) }
    foreach ($k in $saved.Keys) {
        if ($null -eq $saved[$k]) { Remove-ItemProperty $k -Name AccessVBOM -ErrorAction SilentlyContinue }
        else { Set-ItemProperty $k -Name AccessVBOM -Value $saved[$k] -Type DWord }
    }
}

# --- הוספת הרצועה: בונים חבילה חדשה מהקובץ שנשמר (בלי לעדכן במקום) ---
Write-Host 'Adding ribbon tab...'
$utf8 = New-Object Text.UTF8Encoding($false)
$tmp = $target + '.tmp'
if (Test-Path $tmp) { Remove-Item $tmp -Force }
$src = [IO.Compression.ZipFile]::OpenRead($target)
$dst = [IO.Compression.ZipFile]::Open($tmp, 'Create')
try {
    foreach ($en in $src.Entries) {
        if ($en.FullName -eq 'customUI/customUI14.xml') { continue }
        $ne = $dst.CreateEntry($en.FullName, [IO.Compression.CompressionLevel]::Optimal)
        $in = $en.Open(); $out = $ne.Open()
        try {
            if ($en.FullName -eq '_rels/.rels') {
                $rd = New-Object IO.StreamReader($in); $rels = $rd.ReadToEnd()
                if ($rels -notmatch 'customUI14') {
                    $rel = '<Relationship Id="rIdTanachUI" Type="http://schemas.microsoft.com/office/2007/relationships/ui/extensibility" Target="customUI/customUI14.xml"/>'
                    $rels = $rels -replace '</Relationships>', ($rel + '</Relationships>')
                }
                $bytes = $utf8.GetBytes($rels); $out.Write($bytes, 0, $bytes.Length)
            } elseif ($en.FullName -eq '[Content_Types].xml' -and $imgs.Count -gt 0) {
                $rd = New-Object IO.StreamReader($in); $ctx = $rd.ReadToEnd()
                if ($ctx -notmatch 'Extension="png"') { $ctx = $ctx -replace '</Types>', '<Default Extension="png" ContentType="image/png"/></Types>' }
                $bytes = $utf8.GetBytes($ctx); $out.Write($bytes, 0, $bytes.Length)
            } else { $in.CopyTo($out) }
        } finally { $out.Dispose(); $in.Dispose() }
    }
    $ue = $dst.CreateEntry('customUI/customUI14.xml', [IO.Compression.CompressionLevel]::Optimal)
    $uo = $ue.Open(); $ub = $utf8.GetBytes($ribbon); $uo.Write($ub, 0, $ub.Length); $uo.Dispose()
    if ($imgs.Count -gt 0) {
        $rx = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        foreach ($k in $imgs.Keys) {
            $rx += ('<Relationship Id="img_{0}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="images/{0}.png"/>' -f $k)
        }
        $rx += '</Relationships>'
        $re2 = $dst.CreateEntry('customUI/_rels/customUI14.xml.rels', [IO.Compression.CompressionLevel]::Optimal)
        $ro = $re2.Open(); $rb = $utf8.GetBytes($rx); $ro.Write($rb, 0, $rb.Length); $ro.Dispose()
        foreach ($k in $imgs.Keys) {
            $ie = $dst.CreateEntry('customUI/images/' + $k + '.png', [IO.Compression.CompressionLevel]::Optimal)
            $io = $ie.Open(); $ib = [IO.File]::ReadAllBytes($imgs[$k]); $io.Write($ib, 0, $ib.Length); $io.Dispose()
        }
    }
}
finally { $dst.Dispose(); $src.Dispose() }
Move-Item $tmp $target -Force
$okFinal = Test-Dotm $target
if ($okFinal -eq $false) { throw 'The final template file is not valid.' }

$n = ($modules | ForEach-Object { $_.Buttons.Count } | Measure-Object -Sum).Sum
Show-Msg ("ההתקנה הסתיימה: " + $modules.Count + " מודולים, " + $n + " לחצנים.`nפתחו את Word - תופיע לשונית בשם תנ`"ך.") 'Information'

} catch {
    Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host $_.InvocationInfo.PositionMessage
    Show-Msg ("ההתקנה נכשלה:`n" + $_.Exception.Message + "`n`nפרטים מלאים בקובץ:`n" + $log) 'Error'
    exit 1
} finally {
    try { Stop-Transcript | Out-Null } catch {}
}
